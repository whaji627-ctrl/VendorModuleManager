# Vendor Module Manager

Aplikasi Android root untuk mengelola file `.so` dan `.ko` di `/vendor`, `/vendor_dlkm`, `/vendor/lib`, dan `/vendor/lib64`.

## Build APK langsung dari HP (tanpa PC)

Paket ini sudah menyertakan GitHub Actions untuk membangun APK di server GitHub.

1. Ekstrak ZIP ini menggunakan ZArchiver.
2. Buat repository baru di https://github.com/new (perlu akun GitHub).
3. Beri nama `VendorModuleManager`, pilih **Public** atau **Private**, lalu buat repository.
4. Di halaman repository, pilih **Add file → Upload files**.
5. Unggah ISI folder `VendorModuleManager` hasil ekstrak (termasuk folder `.github`, `app`, dan file Gradle) — bukan file ZIP-nya.
6. Tekan **Commit changes**.
7. Buka tab **Actions**, pilih workflow **Build Vendor Module Manager APK**, lalu tekan **Run workflow** jika belum berjalan otomatis.
8. Tunggu sampai job selesai dengan tanda centang hijau.
9. Buka hasil workflow, bagian **Artifacts**, unduh `VendorModuleManager-debug-apk`, lalu ekstrak ZIP artifact. Di dalamnya ada `app-debug.apk`.
10. Buka APK tersebut untuk memasang. Jika Android meminta izin, izinkan instalasi dari sumber itu.

## Build lokal
Dapat dibuka di Android Studio dengan JDK 17 dan Android Gradle Plugin 8.5.2.

## Fitur
- Navigasi `/vendor`, `/vendor/lib`, `/vendor/lib64`, `/vendor_dlkm`
- Daftar file `.so` dan `.ko`
- Backup ke `/data/local/tmp/VendorModuleManager/backups`
- Pilih file pengganti melalui pemilih dokumen Android
- Penggantian file dengan konfirmasi dan backup
- Pengaturan permission 0644 atau 0755

## Peringatan
Aplikasi memerlukan root Magisk/KernelSU/APatch. Android modern dapat menolak remount partisi vendor/vendor_dlkm (misalnya karena EROFS, AVB, atau dynamic partitions). Aplikasi tidak mematikan verity atau melewati proteksi sistem. Penggantian library atau modul yang salah dapat menyebabkan bootloop. Buat backup dan siapkan cara pemulihan sebelum mengubah file.
