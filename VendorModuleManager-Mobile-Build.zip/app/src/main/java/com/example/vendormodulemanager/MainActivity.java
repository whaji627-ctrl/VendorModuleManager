package com.example.vendormodulemanager;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, list; TextView status; String current="/vendor"; ArrayList<String> entries=new ArrayList<>();
    static final int PICK_REPLACE=41; String replaceTarget="";
    String q(String s){ return "'"+s.replace("'","'\\''")+"'"; }
    String su(String cmd){
        try {
            Process p=new ProcessBuilder("su","-c",cmd).redirectErrorStream(true).start();
            ByteArrayOutputStream b=new ByteArrayOutputStream(); InputStream in=p.getInputStream();
            byte[] buf=new byte[4096]; int n; while((n=in.read(buf))>0)b.write(buf,0,n);
            int code=p.waitFor(); return "exit="+code+"\n"+b.toString("UTF-8");
        } catch(Exception e){return "ERROR: "+e.getMessage();}
    }
    void say(String s){status.setText(s);}
    public void onCreate(Bundle b){super.onCreate(b);
        ScrollView sc=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(18,24,18,24); sc.addView(root);
        TextView title=new TextView(this); title.setText("Vendor Module Manager"); title.setTextSize(23); title.setTypeface(null,1); root.addView(title);
        TextView desc=new TextView(this); desc.setText("Root file manager untuk .so / .ko • vendor & vendor_dlkm"); desc.setPadding(0,6,0,12); root.addView(desc);
        LinearLayout nav=new LinearLayout(this);
        addNav(nav,"/vendor"); addNav(nav,"/vendor_dlkm"); addNav(nav,"/vendor/lib64"); addNav(nav,"/vendor/lib");
        root.addView(nav);
        Button up=btn("⬆ Folder induk"); up.setOnClickListener(v->{int i=current.lastIndexOf('/'); current=i<=0?"/":current.substring(0,i); load();}); root.addView(up);
        status=new TextView(this); status.setText("Memeriksa akses root..."); status.setPadding(0,12,0,12); root.addView(status);
        list=new LinearLayout(this); list.setOrientation(1); root.addView(list); setContentView(sc);
        new Thread(()->{String s=su("id"); runOnUiThread(()->say(s)); load();}).start();
    }
    void addNav(LinearLayout row,String path){Button b=btn(path.substring(1)); b.setTextSize(10); b.setOnClickListener(v->{current=path;load();}); row.addView(b,new LinearLayout.LayoutParams(0,-2,1));}
    Button btn(String t){Button b=new Button(this);b.setText(t);return b;}
    void load(){new Thread(()->{
        String out=su("if [ -d "+q(current)+" ]; then ls -la "+q(current)+"; else echo 'Folder tidak ditemukan'; fi");
        String[] lines=out.split("\\n"); ArrayList<String> names=new ArrayList<>();
        for(String line:lines){String[] p=line.trim().split("\\s+"); if(p.length>=NF() && (line.contains(".so")||line.contains(".ko")||p[p.length-1].equals("..")||p[p.length-1].equals("."))) names.add(p[p.length-1]);}
        runOnUiThread(()->{list.removeAllViews(); TextView path=new TextView(this);path.setText("LOKASI: "+current);path.setTypeface(null,1);list.addView(path);
            if(names.isEmpty()){TextView empty=new TextView(this);empty.setText("Tidak ada file .so/.ko yang ditemukan di folder ini.");list.addView(empty);}
            for(String name:names){if(name.equals(".")||name.equals(".."))continue; String full=current+"/"+name;
                LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(8,10,8,10);
                TextView label=new TextView(this);label.setText(name);label.setTextSize(16);label.setTypeface(null,1);card.addView(label);
                TextView meta=new TextView(this);meta.setText(full);meta.setTextSize(11);card.addView(meta);
                LinearLayout actions=new LinearLayout(this);
                Button backup=btn("Backup"), replace=btn("Ganti"), perms=btn("644/755");
                backup.setOnClickListener(v->runAction("Backup", "mkdir -p /data/local/tmp/VendorModuleManager/backups && cp -a "+q(full)+" /data/local/tmp/VendorModuleManager/backups/"));
                replace.setOnClickListener(v->{replaceTarget=full;Intent it=new Intent(Intent.ACTION_OPEN_DOCUMENT);it.setType("*/*");it.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(it,PICK_REPLACE);});
                perms.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Permission").setItems(new String[]{"0644 (umum untuk .so/.ko)","0755 (khusus executable)"},(d,w)->runAction("Permission", "chmod "+(w==0?"0644":"0755")+" "+q(full))).show());
                actions.addView(backup);actions.addView(replace);actions.addView(perms);card.addView(actions);
                View line=new View(this);line.setBackgroundColor(0xffdddddd);card.addView(line,new LinearLayout.LayoutParams(-1,1));list.addView(card);
            }
        });
    }).start();}
    int NF(){return 9;}
    void runAction(String label,String cmd){new AlertDialog.Builder(this).setTitle(label).setMessage("Jalankan operasi root?\n"+cmd).setNegativeButton("Batal",null).setPositiveButton("Lanjut",(d,w)->new Thread(()->{String r=su(cmd);runOnUiThread(()->say(label+": "+r));}).start()).show();}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_REPLACE&&res==RESULT_OK&&data!=null){
        Uri uri=data.getData();try{File temp=new File(getCacheDir(),"incoming.bin");try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(temp)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}
            String staged=temp.getAbsolutePath();
            new AlertDialog.Builder(this).setTitle("Konfirmasi penggantian").setMessage("File target:\n"+replaceTarget+"\n\nAplikasi akan membuat backup lalu menyalin file pengganti. Pastikan arsitektur dan versi cocok.").setNegativeButton("Batal",null).setPositiveButton("Ganti",(d,w)->new Thread(()->{
                String dir="/data/local/tmp/VendorModuleManager/backups";
                String cmd="mkdir -p "+q(dir)+" && cp -a "+q(replaceTarget)+" "+q(dir+"/")+
                    " && mount -o rw,remount /vendor 2>/dev/null; mount -o rw,remount /vendor_dlkm 2>/dev/null; cp "+q(staged)+" "+q(replaceTarget)+" && chmod 0644 "+q(replaceTarget)+" && sync";
                String result=su(cmd);runOnUiThread(()->say("Penggantian: "+result));
            }).start()).show();
        }catch(Exception e){say("Gagal membaca file: "+e.getMessage());}
    }}
}